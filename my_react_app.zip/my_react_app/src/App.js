import React, {useEffect} from 'react';
import {connect} from 'react-redux'
import data from "./js/models/data.json";
import * as actions from './store/actions'
import ToDo from "./js/controllers/index";


function App(props) {

  const { fetchToDoListData,toDoListData} = props

useEffect(() => { 
  fetchToDoListData(data)
},[]);

  return (
    
    <div className="App">
      <ToDo toDoListData={toDoListData} />  
    </div>
  );
}


const mapStateToProps = state => {
  return {
    toDoListData: state.toDoList.toDoListData 
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    fetchToDoListData: (data) => {
      dispatch(actions.fetchToDoListData(data))
    }
  };
}

export default connect(mapStateToProps,mapDispatchToProps) (App);
