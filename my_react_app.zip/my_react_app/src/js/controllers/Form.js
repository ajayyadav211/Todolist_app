import React, { useState } from 'react';

const Form = ({ addTodo }) => {

    const [ userInput, setUserInput ] = useState('');

    const handleChange = (e) => {
        setUserInput(e.currentTarget.value)
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        addTodo(userInput);
        setUserInput("");
    }
    return (
        <form onSubmit={handleSubmit} className = "gap">
            <input value={userInput} type="text" onChange={handleChange} />
            <button>Create Task</button>
        </form>
    );
};

export default Form;