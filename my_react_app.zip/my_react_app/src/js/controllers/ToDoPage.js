import React from 'react';

const ToDo = ({todo, handleClear}) => {

    const handleClick = (e) => {
        e.preventDefault()
        handleClear(e.currentTarget.id)
    }

    return (
        <div id={todo.id} key={todo.id + todo.task} name="todo" value={todo.id} onClick={handleClick} className={todo.complete ? "todo complete" : "todo"}>
            {todo.task}
        </div>
    );
};

export default ToDo;