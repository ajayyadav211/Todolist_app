import React, { useState,useEffect } from 'react';
import ToDoList from "./ToDoList";
import Form from './Form';

export const Todo = (props) => {
    const{toDoListData} = props;
    
    useEffect(() => {
        setToDoList(toDoListData)
      },[toDoListData]);
  
  const [ toDoList, setToDoList ] = useState(toDoListData);

  const handleClear = (id) => {
    let data = toDoList.map(task => {
      return task.id === Number(id) ? { ...task, complete: !task.complete } : { ...task};
    });
    setToDoList(data);
  }

  const handleClearFilter = () => {
    let filterData = toDoList.filter(task => {
      return !task.complete;
    });
    setToDoList(filterData);
  }

  const addTodo = (userInput ) => {
    let data = [...toDoList];
    data = [...data, { id: toDoList.length + 1, task: userInput, complete: false }];
    setToDoList(data);
  }

  return (
    < >
       <h1>To Do List</h1>
       <Form addTodo={addTodo}/>
      <ToDoList toDoList={toDoList} handleClear={handleClear} handleClearFilter={handleClearFilter}/>
      
    </>
  );
}

export default (Todo);
