import React from 'react';
import ToDoPage from './ToDoPage';

const ToDoList = ({toDoList, handleClear, handleClearFilter}) => {
    return (
        <div>
            {toDoList.map((todo,index) => {

                return (
                    <div key={index}>
                    <ToDoPage todo={todo} handleClear={handleClear} />
                    </div>
                )
            })}
            <button className="clearbutton" onClick={handleClearFilter}>Clear Completed</button>
        </div>
    );
};

export default ToDoList;