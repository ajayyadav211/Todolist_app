import configStore from './store-config'

const store = configStore()

export default store