import * as actionTypes from '../actions/actionTypes'

const toDoListState = {
    toDoListData: []
}

const toDoReducer = (state = toDoListState, action) => {
    switch(action.type){
        case actionTypes.TODOLIST_DATA: {
            return {
                ...state,
                ...state.toDoListData,
                toDoListData: action.payload
            }
        }
        default:
            return{
                ...state
            }
    }
}

export default toDoReducer