import {combineReducers} from 'redux';
import toDoReducer from './ToDoList';

const rootReducer = combineReducers({
    toDoList: toDoReducer
})

export default rootReducer;