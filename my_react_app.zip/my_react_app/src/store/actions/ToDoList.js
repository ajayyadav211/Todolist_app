import * as actionTypes from '../actions/actionTypes';

export const fetchToDoListData =(data) => { 
    return{
        type: actionTypes.TODOLIST_DATA,
        payload: data
    }
}